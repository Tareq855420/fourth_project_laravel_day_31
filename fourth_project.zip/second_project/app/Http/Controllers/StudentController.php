<?php

namespace App\Http\Controllers;

use App\Models\student\Student;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    public function student()
    {
        foreach (Student::index() as $student)
        {
            echo $student['name']. '<br/>';
        }
    }

}
